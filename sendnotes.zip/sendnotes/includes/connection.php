<?php
$conn = mysqli_connect("localhost", "root", "", "notes");
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
?>
