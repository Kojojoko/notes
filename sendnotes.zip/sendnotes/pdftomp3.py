import gtts
import PyPDF2
import os
import sys

def pdf_to_text(pdf_file):
    try:
        with open(pdf_file, 'rb') as file:
            pdf = PyPDF2.PdfReader(file)
            text = ''
            for page_num in range(len(pdf.pages)):
                page = pdf.pages[page_num]
                text += page.extract_text()
        return text
    except Exception as e:
        return f"Error extracting text from PDF: {e}"

def text_to_speech(text, lang='en'):
    try:
        tts = gtts.gTTS(text, lang=lang)
        tts.save('C:/Users/Kumaresa pandiyan/Music/output.mp3')
        # Play the generated MP3 file
        os.system('start C:/Users/Kumaresa pandiyan/Music/output.mp3')
        return "Success"
    except Exception as e:
        return f"Error converting text to speech: {e}"

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Error: No PDF file provided.")
        sys.exit(1)
    
    pdf_file = sys.argv[1]
    print(f"Processing file: {pdf_file}")
    
    text = pdf_to_text(pdf_file)
    if "Error" in text:
        print(text)
    else:
        result = text_to_speech(text)
        print(result)