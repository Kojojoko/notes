<?php
include ('includes/connection.php');
include ('includes/adminheader.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file'])) {
    $allowedTypes = ['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain'];
    $fileType = mime_content_type($_FILES['file']['tmp_name']);

    if (in_array($fileType, $allowedTypes)) {
        $uploadDir = 'C:/wamp64/www/College-Notes-Gallery-master/uploads/';
        $uploadFile = $uploadDir . basename($_FILES['file']['name']);

        if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadFile)) {
            // Call the Python script
            $command = escapeshellcmd("python c:/wamp64/www/College-Notes-Gallery-master/pdftomp3.py " . $uploadFile);
            $output = shell_exec($command);
            echo "<pre>$output</pre>"; // Display the output of the Python script
            if ($output === NULL) {
                echo "<div style='text-align: center;'><script>alert('Error executing Python script.');</script></div>";
                
            } elseif (strpos($output, 'Error') !== false) {
                echo "<div style='text-align: center;'><script>alert('Error converting file.');</script></div>";
            } else {
                echo "<div style='text-align: center;'>File successfully uploaded and converted to MP3. You can download it from <a href='c:/wamp64/www/College-Notes-Gallery-master/uploads/" . basename($_FILES['file']['name']) . ".mp3'>here</a>.</div>";
            }
        } else {
            echo "<div style='text-align: center;'><script>alert('File upload failed.');</script></div>";
        }
    } else {
        echo "<div style='text-align: center;'><script>alert('Invalid file type. Only PDF and DOCX files are allowed.');</script></div>";
    }
}

?>

<div id="wrapper">
    <?php include 'includes/adminnav.php';?>
    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-lg-4"></div>
                <div class="col-lg-4">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title"><i class="fa fa-fw fa-file-text"></i> Convert Notes to MP3</h3>
                        </div>
                        <div class="panel-body">
                            <form action="convert.php" method="post" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label for="title">Upload Note</label>
                                    <input type="file" name="file" class="form-control" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Convert PDF to MP3</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
